🔷 PoIC: Proof of Intelligent Compute
A decentralized, trustless compute marketplace that mints tokens only when AI or intelligent jobs are executed and validated.

🔩 System Architecture (Layered)
1. User Layer
user_submit.cpp: Submits jobs to the network

user_bid.cpp: Bids PoIC tokens for compute during auction

auction_watch.cpp: Views live auction state

2. Coordinator Layer (Scheduler & Auction)
job_scheduler.cpp: Assigns shards to nodes from the registry

sharding_logic.cpp: Splits a job into shards

auction_manager.cpp: Selects winning bids when demand > capacity

price_decay.cpp: (Optional) decay logic for idle epochs

task_distributor.cpp: Sends shards to compute nodes

3. Compute Node Layer
node_run.cpp: Runs assigned shards

compute_node.cpp: Executes shard job

execution_hashing.cpp: Hashes job output

validation.cpp: Checks output is AI-like and untampered

block_minter.cpp: Mints a PoIC token and stores block if valid

4. Networking & Node Infrastructure
node_registry.cpp: Tracks live compute nodes and their status

announce.cpp: Broadcasts node availability to the network

peer_connect.cpp: Connects to known peers

grpc_server.cpp: Accepts jobs, bids, heartbeats over gRPC

5. Health & Fault Handling
fault_handler.cpp: Detects node dropouts, reassigns shards

node_register.cpp: Registers node config

node_session.h: Tracks temporary compute sessions

🧱 Data & Type Definitions
Header File	Purpose
job.h	A full job (wallet, model, input, type, shards)
shard.h	A unit of job work (assigned to node)
node.h	Static node profile (GPU, FLOPs, ID)
node_session.h	Session-based compute limits
block.h	A minted token entry after valid compute
bid.h	A user bid for compute
token.h	Wallet + balance management
auction_state.h	Tracks live bids, current epoch, cap, etc.

📁 Project Structure (Simplified)
bash
Copy
Edit
poic/
├── core/                  # Core engine
│   ├── job_scheduler.cpp
│   ├── sharding_logic.cpp
│   ├── compute_node.cpp
│   ├── validation.cpp
│   ├── block_minter.cpp
│   ├── auction_manager.cpp
│   ├── fault_handler.cpp
│   └── execution_hashing.cpp
│
├── network/               # Node communication
│   ├── grpc_server.cpp
│   ├── announce.cpp
│   ├── peer_connect.cpp
│   └── task_distributor.cpp
│
├── cli/                   # Command line tools
│   ├── user_submit.cpp
│   ├── user_bid.cpp
│   ├── auction_watch.cpp
│   ├── node_register.cpp
│   └── node_run.cpp
│
├── models/                # Struct definitions
│   ├── job.h
│   ├── shard.h
│   ├── node.h
│   ├── node_session.h
│   ├── block.h
│   ├── bid.h
│   ├── token.h
│   └── auction_state.h
│
├── storage/               # Job data and ledger
│   ├── blocks/
│   ├── ledger/
│   ├── hashes/
│   ├── outputs/
│   ├── logs/
│   └── shards/
│
├── config/
│   ├── auction.toml
│   ├── nodes.toml
│   └── job_settings.toml
│
├── main.cpp
└── CMakeLists.txt
🪙 What Makes PoIC Unique
✅ Proof-of-Work = Proof-of-AI

🚫 No mining waste — only meaningful compute (ML inference, sim, training)

🔐 Trustless validation via hash + output structure inspection

🪙 Token rewards based on compute, not randomness

⚡ Auction system handles demand vs capacity with real bidding

💻 Anyone with compute can earn — no KYC, no identity, just compute