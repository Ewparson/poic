// File: announce.cpp

#include <iostream>
#include <string>
#include <nlohmann/json.hpp>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "node_registry.h"

using json = nlohmann::json;

// ------------------------------------------------------------
// Function: broadcast_announcement
// Purpose:  Send a UDP broadcast with this node’s metadata,
//           then register the node locally (populating node.ip).
// ------------------------------------------------------------
void broadcast_announcement(const std::string& node_id,
                            const std::string& gpu,
                            int                flops,
                            const std::string& ip,
                            int                port) {
    // 1) Create UDP socket for broadcast
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        std::cerr << "Failed to create socket.\n";
        return;
    }

    int broadcastEnable = 1;
    setsockopt(sock, SOL_SOCKET, SO_BROADCAST,
               &broadcastEnable, sizeof(broadcastEnable));

    sockaddr_in addr;
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(9000);             // broadcast port
    addr.sin_addr.s_addr = inet_addr("255.255.255.255");

    // 2) Build JSON payload
    json msg = {
        {"node_id",  node_id},
        {"gpu",      gpu},
        {"flops",    flops},
        {"ip",       ip},
        {"port",     port},
        {"status",   "online"},
        {"timestamp", std::time(nullptr)}
    };

    std::string payload = msg.dump();

    // 3) Broadcast
    sendto(sock,
           payload.c_str(), payload.size(),
           0,
           reinterpret_cast<sockaddr*>(&addr), sizeof(addr));
    close(sock);

    // 4) Register locally (populates registry[node_id].ip and .port)
    registerNode(node_id, ip, port, flops);

    std::cout << "📡 Announced node '" << node_id
              << "' at " << ip << ":" << port << "\n";
}
