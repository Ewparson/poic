// task_distributor.cpp

#include <iostream>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
#include <grpcpp/grpcpp.h>
#include "node_registry.h"
#include "shard_delivery.grpc.pb.h"  // generated from shard_delivery.proto

namespace fs = std::filesystem;
using json = nlohmann::json;

// ------------------------------------------------------------
// Function: deliverShardToNode
// Purpose:  Use gRPC to send a shard to a remote node
// ------------------------------------------------------------
void deliverShardToNode(const json& shard, const std::string& node_ip, int port = 50051) {
    std::string address = node_ip + ":" + std::to_string(port);
    auto channel = grpc::CreateChannel(address, grpc::InsecureChannelCredentials());
    std::unique_ptr<ShardDelivery::Stub> stub = ShardDelivery::NewStub(channel);

    DeliverRequest request;
    request.set_job_id(shard["job_id"]);
    request.set_shard_id(shard["shard_id"]);
    request.set_payload(shard.dump());

    DeliverResponse response;
    grpc::ClientContext context;

    grpc::Status status = stub->DeliverShard(&context, request, &response);

    if (status.ok() && response.success()) {
        std::cout << "📤 Delivered shard to " << address << " successfully.\n";
    } else {
        std::cerr << "❌ Failed to deliver shard to " << address << ": "
                  << status.error_message() << "\n";
    }
}

// ------------------------------------------------------------
// Function: distributeAssignedShards
// Purpose:  Load assigned shards from disk and deliver to nodes
// ------------------------------------------------------------
void distributeAssignedShards() {
    for (const auto& file : fs::directory_iterator("jobs/shards/")) {
        std::ifstream in(file.path());
        json shard;
        in >> shard;

        if (shard["status"] != "assigned") continue;
        std::string node_id = shard["assigned_to"];
        if (!registry.count(node_id)) {
            std::cerr << "⚠️ No such node in registry: " << node_id << "\n";
            continue;
        }

        auto& node = registry[node_id];
        deliverShardToNode(shard, node.ip, node.port);

        // Update shard status
        shard["status"] = "in_progress";
        shard["delivery_time"] = std::time(nullptr);

        std::ofstream out(file.path());
        out << shard.dump(4);
        out.close();
    }
}
