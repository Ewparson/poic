// peer_connect.cpp

#include <iostream>
#include "node_registry.h"
#include <fstream>
#include <vector>
#include <string>
#include <nlohmann/json.hpp>
#include <asio.hpp> // Or raw socket API if no Asio

using json = nlohmann::json;
using asio::ip::tcp;

struct Peer {
    std::string ip;
    int port;
};

std::vector<Peer> loadPeers(const std::string& path = "config/nodes.toml") {
    std::vector<Peer> peers;
    std::ifstream file(path);
    if (!file.is_open()) return peers;

    std::string line;
    Peer p;
    while (std::getline(file, line)) {
        if (line.find("ip") != std::string::npos)
            p.ip = line.substr(line.find("=") + 2);
        else if (line.find("port") != std::string::npos) {
            p.port = std::stoi(line.substr(line.find("=") + 2));
            peers.push_back(p);
            p = {}; // reset for next peer
        }
    }
    return peers;
}


// ------------------------------------------------------------
// Function: connectToPeers
// Purpose:  Establish outgoing connections using each peer’s ip/port.
// ------------------------------------------------------------
void connectToPeers(const std::vector<std::string>& peer_ids) {
    for (auto& id : peer_ids) {
        auto it = registry.find(id);
        if (it == registry.end()) continue;
        const NodeInfo& peer = it->second;

        // e.g. open a gRPC channel at peer.ip:peer.port
        std::string target = peer.ip + ":" + std::to_string(peer.port);
        connectGRPC(target);
    }
}

void connectToPeers(const std::vector<Peer>& peers) {
    asio::io_context io_context;

    for (const auto& peer : peers) {
        try {
            tcp::resolver resolver(io_context);
            auto endpoints = resolver.resolve(peer.ip, std::to_string(peer.port));
            tcp::socket socket(io_context);
            asio::connect(socket, endpoints);

            std::string handshake = "PoIC/hello";
            asio::write(socket, asio::buffer(handshake));

            std::cout << "🔗 Connected to peer " << peer.ip << ":" << peer.port << "\n";
        } catch (...) {
            std::cerr << "❌ Failed to connect to peer " << peer.ip << "\n";
        }
    }
}

