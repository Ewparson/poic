// grpc_server.cpp
#include "poic.grpc.pb.h"
#include <grpcpp/grpcpp.h>
#include "job_scheduler.cpp"
#include "node_registry.cpp"
#include "auction_manager.cpp"

class PoICServiceImpl final : public PoIC::Service {
    grpc::Status SubmitJob(grpc::ServerContext* context,
                           const JobRequest* request,
                           JobAck* response) override {
        // Convert to JSON and save
        json job = {
            {"job_id", request->job_id()},
            {"wallet", request->wallet()},
            {"model", request->model()},
            {"input", request->input()},
            {"type", request->type()},
            {"shards", request->shards()},
            {"status", "unassigned"},
            {"timestamp", std::time(nullptr)}
        };
        std::ofstream out("jobs/queue/" + request->job_id() + ".json");
        out << job.dump(4);
        response->set_accepted(true);
        response->set_job_id(request->job_id());
        return grpc::Status::OK;
    }

    grpc::Status RegisterNode(grpc::ServerContext*,
                              const NodeInfo* node,
                              Status* reply) override {
        // Store in node_registry
        NodeInfo n = {
            node->id(), node->gpu(), node->flops(), "online",
            node->session_time(), node->max_jobs(), std::time(nullptr)
        };
        registerNode(n);
        reply->set_ok(true);
        reply->set_message("Node registered");
        return grpc::Status::OK;
    }

    grpc::Status SubmitBid(grpc::ServerContext*,
                           const Bid* bid,
                           Status* reply) override {
        // Append bid to auction file
        json j = {
            {"wallet", bid->wallet()},
            {"job_id", bid->job_id()},
            {"amount", bid->amount()},
            {"timestamp", std::time(nullptr)}
        };
        std::ofstream out("storage/auction_state/current_bids.json", std::ios::app);
        out << j.dump() << "\n";
        reply->set_ok(true);
        reply->set_message("Bid received");
        return grpc::Status::OK;
    }
};

