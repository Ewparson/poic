// job.h
#pragma once
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>

struct Job {
    std::string job_id;
    std::string wallet;
    std::string model_path;
    std::string input_path;
    std::string type;            // "inference", "training", etc.
    int shards;
    double max_bid;              // optional: max token spend
    std::string status;          // "unassigned", "sharded", "scheduled", "completed"
    std::time_t timestamp;

    static Job from_json(const nlohmann::json& j) {
        return {
            j["job_id"],
            j["wallet"],
            j["model"],
            j["input"],
            j["type"],
            j["shards"],
            j.value("max_bid", 0.0),
            j.value("status", "unassigned"),
            j["timestamp"]
        };
    }

    nlohmann::json to_json() const {
        return {
            {"job_id", job_id},
            {"wallet", wallet},
            {"model", model_path},
            {"input", input_path},
            {"type", type},
            {"shards", shards},
            {"max_bid", max_bid},
            {"status", status},
            {"timestamp", timestamp}
        };
    }
};

