// block.h
#pragma once
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>

struct Block {
    int block_id;
    std::string job_id;
    std::string wallet;
    std::string hash;
    std::time_t timestamp;
    double reward;

    static Block from_json(const nlohmann::json& j) {
        return {
            j["block_id"],
            j["job_id"],
            j["wallet"],
            j["hash"],
            j["timestamp"],
            j["reward"]
        };
    }

    nlohmann::json to_json() const {
        return {
            {"block_id", block_id},
            {"job_id", job_id},
            {"wallet", wallet},
            {"hash", hash},
            {"timestamp", timestamp},
            {"reward", reward}
        };
    }
};

