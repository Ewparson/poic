// bid.h
#pragma once
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>

struct Bid {
    std::string wallet;
    std::string job_id;
    double amount;
    std::time_t timestamp;

    static Bid from_json(const nlohmann::json& j) {
        return {
            j["wallet"],
            j["job_id"],
            j["amount"],
            j["timestamp"]
        };
    }

    nlohmann::json to_json() const {
        return {
            {"wallet", wallet},
            {"job_id", job_id},
            {"amount", amount},
            {"timestamp", timestamp}
        };
    }
};
