// # token.h.cpp
#pragma once

#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
namespace fs = std::filesystem;

const std::string LEDGER_DIR = "storage/ledger/";

// ------------------------------------------------------------
// Logger Macros
// Purpose: Simple logging for errors and warnings.
// ------------------------------------------------------------
#define LOG_ERROR(msg) std::cerr << "[ERROR] " << msg << std::endl
#define LOG_WARNING(msg) std::cerr << "[WARNING] " << msg << std::endl

// ------------------------------------------------------------
// Function: loadWallet
// Purpose: Load or initialize a wallet ledger from disk.
// ------------------------------------------------------------
json loadWallet(const std::string& wallet) {
    std::string path = LEDGER_DIR + wallet + ".json";
    json ledger;

    // If ledger does not exist, initialize default
    if (!fs::exists(path)) {
        LOG_WARNING("Wallet file not found, initializing new ledger: " + path);
        ledger["wallet"] = wallet;
        ledger["balance"] = 0.0;
        return ledger;
    }

    std::ifstream in(path);
    if (!in.is_open()) {
        LOG_ERROR("Failed to open wallet file: " + path);
        ledger["wallet"] = wallet;
        ledger["balance"] = 0.0;
        return ledger;
    }

    try {
        in >> ledger;
    } catch (const json::exception& e) {
        LOG_ERROR(std::string("JSON parse error for file ") + path + ": " + e.what());
        ledger["wallet"] = wallet;
        ledger["balance"] = 0.0;
    }

    return ledger;
}

// ------------------------------------------------------------
// Function: saveWallet
// Purpose: Persist wallet ledger to disk atomically.
// ------------------------------------------------------------
bool saveWallet(const std::string& wallet, const json& ledger) {
    std::string path = LEDGER_DIR + wallet + ".json";
    std::string tmpPath = path + ".tmp";

    std::ofstream out(tmpPath);
    if (!out.is_open()) {
        LOG_ERROR("Failed to open temporary file for writing: " + tmpPath);
        return false;
    }

    try {
        out << ledger.dump(4);
        out.close();
        fs::rename(tmpPath, path);
    } catch (const std::exception& e) {
        LOG_ERROR(std::string("Error saving wallet file ") + path + ": " + e.what());
        // Cleanup temporary file
        fs::remove(tmpPath);
        return false;
    }

    return true;
}
