// node.h
#pragma once
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>

struct NodeSession {
    std::string node_id;
    int max_jobs;
    int max_duration_sec;
    int jobs_completed;
    std::time_t start_time;
    bool active;

    NodeSession(const std::string& id, int jobs, int time_limit)
        : node_id(id), max_jobs(jobs), max_duration_sec(time_limit), jobs_completed(0),
          start_time(std::time(nullptr)), active(true) {}

    bool isExpired() const {
        std::time_t now = std::time(nullptr);
        if ((max_jobs > 0 && jobs_completed >= max_jobs) ||
            (max_duration_sec > 0 && (now - start_time) >= max_duration_sec)) {
            return true;
        }
        return false;
    }

    void incrementJob() {
        jobs_completed++;
        if (isExpired()) active = false;
    }

    nlohmann::json to_json() const {
        return {
            {"node_id", node_id},
            {"max_jobs", max_jobs},
            {"max_duration_sec", max_duration_sec},
            {"jobs_completed", jobs_completed},
            {"start_time", start_time},
            {"active", active}
        };
    }

    static NodeSession from_json(const nlohmann::json& j) {
        NodeSession s(
            j["node_id"],
            j["max_jobs"],
            j["max_duration_sec"]
        );
        s.jobs_completed = j["jobs_completed"];
        s.start_time = j["start_time"];
        s.active = j["active"];
        return s;
    }
};

