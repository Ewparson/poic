// shard.h
#pragma once
#include <string>
#include <nlohmann/json.hpp>

struct Shard {
    std::string job_id;
    int shard_id;
    std::string input_path;
    std::string output_path;
    std::string status;          // unassigned, assigned, completed
    std::string assigned_to;     // node_id
    std::time_t last_update;

    // Parse from JSON
    static Shard from_json(const nlohmann::json& j) {
        return {
            j["job_id"],
            j["shard_id"],
            j["input"],
            j["output"],
            j.value("status", "unassigned"),
            j.value("assigned_to", ""),
            j.value("last_update", std::time(nullptr))
        };
    }

    // Convert to JSON
    nlohmann::json to_json() const {
        return {
            {"job_id", job_id},
            {"shard_id", shard_id},
            {"input", input_path},
            {"output", output_path},
            {"status", status},
            {"assigned_to", assigned_to},
            {"last_update", last_update}
        };
    }
};

