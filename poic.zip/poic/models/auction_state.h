// auction_state.h
#pragma once
#include <vector>
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>
#include "bid.h"

struct AuctionState {
    int epoch;
    int slots_available;
    int compute_cap;
    int current_usage;
    std::time_t epoch_end_time;
    bool in_auction_mode;
    std::vector<Bid> bids;

    static AuctionState from_json(const nlohmann::json& j) {
        AuctionState state;
        state.epoch = j["epoch"];
        state.slots_available = j["slots_available"];
        state.compute_cap = j["compute_cap"];
        state.current_usage = j["current_usage"];
        state.epoch_end_time = j["epoch_end_time"];
        state.in_auction_mode = j["in_auction_mode"];

        for (const auto& b : j["bids"]) {
            state.bids.push_back(Bid::from_json(b));
        }

        return state;
    }

    nlohmann::json to_json() const {
        nlohmann::json j;
        j["epoch"] = epoch;
        j["slots_available"] = slots_available;
        j["compute_cap"] = compute_cap;
        j["current_usage"] = current_usage;
        j["epoch_end_time"] = epoch_end_time;
        j["in_auction_mode"] = in_auction_mode;
        j["bids"] = nlohmann::json::array();

        for (const auto& b : bids) {
            j["bids"].push_back(b.to_json());
        }

        return j;
    }

    bool isEpochExpired() const {
        return std::time(nullptr) > epoch_end_time;
    }
};

