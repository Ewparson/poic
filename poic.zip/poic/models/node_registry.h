// node_registry.h
#pragma once

#include <string>
#include <map>
#include <ctime>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// ------------------------------------------------------------
// Struct: NodeInfo
// Purpose: Carries all relevant metadata for each compute node,
//          including compute accounting and network address.
// ------------------------------------------------------------
struct NodeInfo {
    std::string id;            // unique node ID
    std::string ip;            // IPv4 address or hostname
    int         port;          // RPC or HTTP port
    double      total_flops;   // Total FLOPs available this session
    double      available_flops; // Remaining FLOPs for this session
    int         running_jobs;  // Number of currently assigned shards
    int         gflops;        // FLOPs per second performance metric
    int         session_time;  // Allowed session time (seconds)
    std::string status;       // online/offline
    std::time_t last_seen;    // heartbeat timestamp

    // --------------------------------------------------------
    // Function: to_json
    // Purpose:  Converts NodeInfo to a JSON object for persistence
    // --------------------------------------------------------
    json to_json() const {
        return json{
            {"id",             id},
            {"ip",             ip},
            {"port",           port},
            {"total_flops",    total_flops},
            {"available_flops",available_flops},
            {"running_jobs",   running_jobs},
            {"gflops",         gflops},
            {"session_time",   session_time},
            {"status",         status},
            {"last_seen",      last_seen}
        };
    }

    // --------------------------------------------------------
    // Function: from_json
    // Purpose:  Constructs NodeInfo from a JSON object
    // --------------------------------------------------------
    static NodeInfo from_json(const json& j) {
        NodeInfo n;
        n.id              = j.at("id").get<std::string>();
        n.ip              = j.at("ip").get<std::string>();
        n.port            = j.at("port").get<int>();
        n.total_flops     = j.at("total_flops").get<double>();
        n.available_flops = j.at("available_flops").get<double>();
        n.running_jobs    = j.at("running_jobs").get<int>();
        n.gflops          = j.at("gflops").get<int>();
        n.session_time    = j.at("session_time").get<int>();
        n.status          = j.at("status").get<std::string>();
        n.last_seen       = j.at("last_seen").get<std::time_t>();
        return n;
    }
};

// ------------------------------------------------------------
// Global registry mapping node IDs to NodeInfo
// ------------------------------------------------------------
extern std::map<std::string, NodeInfo> registry;

// ------------------------------------------------------------
// Function: loadRegistryFromFile
// Purpose:  Load registry data including compute accounting
// ------------------------------------------------------------
void loadRegistryFromFile(const std::string& path = "config/nodes_registry.json");

// ------------------------------------------------------------
// Function: saveRegistryToFile
// Purpose:  Persist registry data including compute accounting
// ------------------------------------------------------------
void saveRegistryToFile(const std::string& path = "config/nodes_registry.json");

// ------------------------------------------------------------
// Function: registerNode
// Purpose:  Adds or updates a node entry (called on announce)
// ------------------------------------------------------------
void registerNode(const std::string& node_id,
                  const std::string& ip,
                  int port,
                  int gflops,
                  int session_time);

// ------------------------------------------------------------
// Function: heartbeat
// Purpose:  Updates node heartbeat without resetting resources
// ------------------------------------------------------------
void heartbeat(const std::string& node_id);

// ------------------------------------------------------------
// Function: cleanupInactiveNodes
// Purpose:  Mark nodes offline and zero resources if stale
// ------------------------------------------------------------
void cleanupInactiveNodes(int timeout_seconds = 300);

// ------------------------------------------------------------
// Function: assignShardToNode
// Purpose:  Reserve FLOPs and increment job count on assignment
// ------------------------------------------------------------
bool assignShardToNode(const std::string& node_id, double flops_required);

// ------------------------------------------------------------
// Function: releaseShardResources
// Purpose:  Reclaim FLOPs and decrement job count on completion/failure
// ------------------------------------------------------------
void releaseShardResources(const std::string& node_id, double flops_to_credit);
