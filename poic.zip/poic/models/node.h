// node.h
#pragma once
#include <string>
#include <nlohmann/json.hpp>

struct Node {
    std::string id;
    std::string ip;                 // NEW: IP address of the node
    std::string gpu;
    int flops;
    std::string status;            // online, offline, idle
    int session_time;              // how long node will stay available (sec)
    int max_jobs;                  // how many jobs the node is willing to take
    std::time_t last_heartbeat;    // UNIX timestamp

    static Node from_json(const nlohmann::json& j) {
        return {
            j["id"],
            j.value("ip", "127.0.0.1"),  // default to localhost if missing
            j["gpu"],
            j["flops"],
            j["status"],
            j["session_time"],
            j["max_jobs"],
            j["last_heartbeat"]
        };
    }

    nlohmann::json to_json() const {
        return {
            {"id", id},
            {"ip", ip},
            {"gpu", gpu},
            {"flops", flops},
            {"status", status},
            {"session_time", session_time},
            {"max_jobs", max_jobs},
            {"last_heartbeat", last_heartbeat}
        };
    }
};
