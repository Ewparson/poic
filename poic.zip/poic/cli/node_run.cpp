// node_run.cpp
#include <iostream>
#include <chrono>
#include <thread>
#include <filesystem>
#include <cstdlib>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
namespace fs = std::filesystem;

int runShard(const std::string& shard_path, const std::string& output_path) {
    // Replace this with your real model execution
    std::cout << "Running shard: " << shard_path << std::endl;

    // Simulate compute delay
    std::this_thread::sleep_for(std::chrono::seconds(2));

    // Fake result output
    std::ofstream out(output_path);
    out << "result from " << shard_path << "\n";
    out.close();

    return 0; // success
}

std::map<std::string, std::string> parseArgs(int argc, char* argv[]) {
    std::map<std::string, std::string> args;
    for (int i = 1; i < argc - 1; i += 2) {
        args[argv[i]] = argv[i + 1];
    }
    return args;
}

int main(int argc, char* argv[]) {
    auto args = parseArgs(argc, argv);

    std::string node_id = args["--id"];
    int time_limit = args.count("--time") ? std::stoi(args["--time"]) : -1;
    int max_jobs = args.count("--max_jobs") ? std::stoi(args["--max_jobs"]) : -1;

    int jobs_done = 0;
    auto start_time = std::chrono::steady_clock::now();

    while (true) {
        // Exit if job cap is reached
        if (max_jobs != -1 && jobs_done >= max_jobs) break;

        // Exit if time limit is exceeded
        if (time_limit != -1) {
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(
                std::chrono::steady_clock::now() - start_time
            ).count();
            if (elapsed > time_limit) break;
        }

        // Look for new shard to run
        std::string shard_path = "jobs/queue/shard_" + std::to_string(jobs_done) + ".json";
        if (!fs::exists(shard_path)) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            continue;
        }

        std::string output_path = "storage/outputs/output_" + std::to_string(jobs_done) + ".txt";
        int status = runShard(shard_path, output_path);

        if (status == 0) {
            std::cout << "Shard completed. Output saved to: " << output_path << "\n";
            jobs_done++;
        } else {
            std::cerr << "Shard failed.\n";
        }
    }

    std::cout << "Node session complete.\n";
    return 0;
}
