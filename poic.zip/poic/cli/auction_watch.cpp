// auction_watch.cpp
#include <iostream>
#include <fstream>
#include <nlohmann/json.hpp>  // For JSON parsing: https://github.com/nlohmann/json
#include <chrono>
#include <thread>
#include <vector>

using json = nlohmann::json;

// ------------------------------------------------------------
// Function: printAuctionState
// Purpose:  Load & display the current auction snapshot
// ------------------------------------------------------------
void printAuctionState() {
    std::ifstream file("storage/auction_state.json");
    if (!file.is_open()) {
        std::cerr << "Could not open storage/auction_state.json\n";
        return;
    }

    json state;
    file >> state;

    std::cout << "=== PoIC Live Auction ===\n";
    std::cout << "Epoch:               " << state["epoch"] << "\n";
    std::cout << "Time Left:           " << state["time_left"] << " seconds\n";
    std::cout << "Current Floor Price: " << state["floor_price"] << " tokens\n\n";

    std::cout << "Top Bids:\n";
    for (auto& bid : state["top_bids"]) {
        std::cout << "- Wallet: "   << bid["wallet"]
                  << ", Bid: "     << bid["amount"]
                  << ", Timestamp: "<< bid["timestamp"] << "\n";
    }

    std::cout << "\nCompute Remaining: " << state["compute_remaining"] << " FLOPs\n\n";
}

// ------------------------------------------------------------
// Function: printLiveBids
// Purpose:  Read and display every JSON line in current_bids.json
// ------------------------------------------------------------
void printLiveBids() {
    std::ifstream file("storage/auction_state/current_bids.json");
    if (!file.is_open()) {
        std::cerr << "Cannot open storage/auction_state/current_bids.json\n";
        return;
    }

    std::string line;
    std::vector<json> bids;
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        bids.push_back(json::parse(line));
    }

    std::cout << "=== Live Bids (" << bids.size() << ") ===\n";
    for (auto& b : bids) {
        std::cout << "Wallet: "   << b["wallet"]
                  << " | Job: "   << b["job_id"]
                  << " | Amount: "<< b["amount"]
                  << " | Time: "  << b["timestamp"] << "\n";
    }
    std::cout << "\n";
}

int main() {
    while (true) {
        #ifdef _WIN32
            system("CLS");
        #else
            system("clear");
        #endif

        printAuctionState();
        printLiveBids();

        std::this_thread::sleep_for(std::chrono::seconds(3));
    }
    return 0;
}
