// user_submit.cpp
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <ctime>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
namespace fs = std::filesystem;

std::map<std::string, std::string> parseArgs(int argc, char* argv[]) {
    std::map<std::string, std::string> args;
    for (int i = 1; i < argc - 1; i += 2) {
        args[argv[i]] = argv[i + 1];
    }
    return args;
}

std::string generateJobID() {
    std::time_t now = std::time(nullptr);
    return "job_" + std::to_string(now);
}

int main(int argc, char* argv[]) {
    auto args = parseArgs(argc, argv);

    if (!args.count("--file") || !args.count("--type") || !args.count("--wallet")) {
        std::cerr << "Usage: ./user_submit --file <path> --type <inference|training> --wallet <wallet>\n";
        return 1;
    }

    std::string file_path = args["--file"];
    std::string job_type = args["--type"];
    std::string wallet = args["--wallet"];
    std::string desc = args.count("--desc") ? args["--desc"] : "No description";
    double max_bid = args.count("--max_bid") ? std::stod(args["--max_bid"]) : 0.0;

    if (!fs::exists(file_path)) {
        std::cerr << "Error: File not found.\n";
        return 1;
    }

    std::string job_id = generateJobID();
    std::string destination = "jobs/queue/" + job_id + ".json";
    std::string copy_to = "jobs/uploads/" + job_id + ".zip";

    fs::copy(file_path, copy_to);

    json job;
    job["job_id"] = job_id;
    job["wallet"] = wallet;
    job["type"] = job_type;
    job["file"] = copy_to;
    job["description"] = desc;
    job["max_bid"] = max_bid;
    job["timestamp"] = std::time(nullptr);

    std::ofstream out(destination);
    out << job.dump(4);
    out.close();

    std::cout << "Job submitted successfully!\nJob ID: " << job_id << std::endl;

    return 0;
}

