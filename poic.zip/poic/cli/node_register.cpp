// node_register.cpp
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

std::map<std::string, std::string> parseArgs(int argc, char* argv[]) {
    std::map<std::string, std::string> args;
    for (int i = 1; i < argc - 1; i += 2) {
        args[argv[i]] = argv[i + 1];
    }
    return args;
}

int main(int argc, char* argv[]) {
    if (argc < 7) {
        std::cerr << "Usage: ./node_register --id <ID> --flops <FLOPs> --gpu <GPU> --ip <IP> [--duration <sec>] [--max_jobs <int>]\n";
        return 1;
    }

    auto args = parseArgs(argc, argv);

    json node;
    node["id"] = args["--id"];
    node["ip"] = args["--ip"];
    node["flops"] = std::stoi(args["--flops"]);
    node["gpu"] = args["--gpu"];
    node["duration"] = args.count("--duration") ? std::stoi(args["--duration"]) : -1;
    node["max_jobs"] = args.count("--max_jobs") ? std::stoi(args["--max_jobs"]) : -1;
    node["status"] = "online";
    node["last_heartbeat"] = std::time(nullptr);

    std::string path = "config/nodes_registry.json";
    json registry;

    // Load existing registry if present
    std::ifstream in(path);
    if (in.is_open()) {
        in >> registry;
        in.close();
    }

    // Save/overwrite this node entry
    registry[node["id"]] = node;

    std::ofstream out(path);
    if (out.is_open()) {
        out << registry.dump(4);
        out.close();n        std::cout << "Node registered to nodes_registry.json successfully.\n";
    } else {
        std::cerr << "Failed to open nodes_registry.json.\n";
        return 1;
    }

    return 0;
}
