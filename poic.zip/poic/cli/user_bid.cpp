// user_bid.cpp
#include <iostream>
#include <fstream>
#include <ctime>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

std::map<std::string, std::string> parseArgs(int argc, char* argv[]) {
    std::map<std::string, std::string> args;
    for (int i = 1; i < argc - 1; i += 2) {
        args[argv[i]] = argv[i + 1];
    }
    return args;
}

int main(int argc, char* argv[]) {
    auto args = parseArgs(argc, argv);

    if (args.count("--wallet") == 0 || args.count("--job_id") == 0 || args.count("--amount") == 0) {
        std::cerr << "Usage: ./user_bid --wallet <wallet> --job_id <id> --amount <tokens>\n";
        return 1;
    }

    std::string wallet = args["--wallet"];
    std::string job_id = args["--job_id"];
    double amount = std::stod(args["--amount"]);
    std::time_t timestamp = std::time(nullptr);

    json bid;
    bid["wallet"] = wallet;
    bid["job_id"] = job_id;
    bid["amount"] = amount;
    bid["timestamp"] = timestamp;

    // Append to auction file (temporary local sim)
    std::ofstream file("storage/auction_state/current_bids.json", std::ios::app);
    if (file.is_open()) {
        file << bid.dump() << std::endl;
        file.close();
        std::cout << "Bid submitted: " << amount << " PoIC tokens on job " << job_id << "\n";
    } else {
        std::cerr << "Error: could not open bid file.\n";
        return 1;
    }

    return 0;
}

