// main.cpp
#include <iostream>
#include <thread>
#include <chrono>

#include "node_registry.cpp"
#include "job_scheduler.cpp"
#include "fault_handler.cpp"
#include "task_distributor.cpp"
#include "auction_manager.cpp"
#include "peer_connect.cpp"
#include "announce.cpp"
#include "grpc_server.cpp"

using namespace std::chrono_literals;

// ------------------------------------------------------------
// Function: scheduler_loop
// Purpose:  Assign shards, detect failures, and schedule jobs
// ------------------------------------------------------------
void scheduler_loop() {
    while (true) {
        distributeAssignedShards();   // push shards to nodes
        scanForShardFailures();       // reassign dead shards
        scheduleJobs();               // pick unassigned shards + assign nodes
        std::this_thread::sleep_for(10s);
    }
}

// ------------------------------------------------------------
// Function: auction_loop
// Purpose:  Run auction rounds at a fixed interval
// ------------------------------------------------------------
void auction_loop() {
    while (true) {
        processAuctionRound();        // run bid round
        std::this_thread::sleep_for(30s);
    }
}

// ------------------------------------------------------------
// Function: network_loop
// Purpose:  Broadcast announcements & sync with peers
// ------------------------------------------------------------
void network_loop() {
    while (true) {
        broadcast_announcement("node_123", "RTX 3060", 15000, 50051);
        connectToPeers(loadPeers());
        std::this_thread::sleep_for(60s);
    }
}

// ------------------------------------------------------------
// Function: main
// Purpose:  Initialize everything and start background services
// ------------------------------------------------------------
int main() {
    std::cout << "🚀 Starting PoIC node...\n";

    // Load static node registry from disk
    loadRegistryFromFile();

    // Start background loops (detached so they keep running)
    std::thread(scheduler_loop).detach();
    std::thread(auction_loop  ).detach();
    std::thread(network_loop  ).detach();

    // Start gRPC server (blocking call)
    RunServer();

    return 0;
}
