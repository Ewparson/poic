//fault_handler.cpp

//fault_handler.cpp

#include <iostream>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
#include <ctime>
#include "node_registry.cpp" // Access to node status, heartbeats

using json = nlohmann::json;
namespace fs = std::filesystem;

const int SHARD_TIMEOUT = 300; // seconds (5 minutes)

// ------------------------------------------------------------
// Function: isShardStale
// Purpose: Determines if a shard is considered stale and needs reassignment
// ------------------------------------------------------------
bool isShardStale(const std::string& shard_path) {
    std::ifstream file(shard_path);
    if (!file.is_open()) return false;

    json shard;
    file >> shard;

    if (shard["status"] != "assigned") return false;

    std::time_t last_update = shard.value("last_update", 0);
    std::time_t now = std::time(nullptr);
    std::string assigned_node = shard["assigned_to"];

    bool node_dead = registry.count(assigned_node) == 0 || registry[assigned_node].status != "online";
    bool timeout_expired = (now - last_update > SHARD_TIMEOUT);

    return node_dead || timeout_expired;
}

// ------------------------------------------------------------
// Function: creditFlopsToNode
// Purpose: Reclaim unused compute capacity from failed shard
// ------------------------------------------------------------
void creditFlopsToNode(const std::string& node_id, int flops) {
    if (registry.count(node_id) && registry[node_id].status == "online") {
        registry[node_id].available_flops += flops;
        std::cout << "🔁 Reclaimed " << flops << " FLOPs from node " << node_id << "\n";
    }
}

// ------------------------------------------------------------
// Function: reassignShard
// Purpose: Mark a stale shard as unassigned and log the fault
// ------------------------------------------------------------
void reassignShard(const std::string& shard_path) {
    std::ifstream file(shard_path);
    json shard;
    file >> shard;
    file.close();

    std::string failed_node = shard.value("assigned_to", "");
    int flops = shard.value("estimated_flops", 0);

    creditFlopsToNode(failed_node, flops);

    shard["status"] = "unassigned";
    shard.erase("assigned_to");

    std::ofstream out(shard_path);
    out << shard.dump(4);
    out.close();

    std::cout << "⚠️ Reverted shard " << shard["shard_id"] << " from node " << failed_node << "\n";

    std::ofstream log("storage/logs/fault_log.txt", std::ios::app);
    log << "Shard " << shard["shard_id"] << " (job " << shard["job_id"] << ") failed on node " << failed_node << "\n";
    log.close();
}

// ------------------------------------------------------------
// Function: scanForShardFailures
// Purpose: Iterate through all shards and reassign those detected as stale
// ------------------------------------------------------------
void scanForShardFailures() {
    std::cout << "[FaultHandler] Scanning for shard failures...\n";

    for (const auto& file : fs::directory_iterator("jobs/shards/")) {
        if (isShardStale(file.path())) {
            reassignShard(file.path());
        }
    }
}