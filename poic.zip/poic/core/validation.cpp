// File: validation.cpp
// File: artifact_validator.cpp
// ------------------------------------------------------------
// Provides C++-only validation for intelligent model artifacts
// Options:
// 1. Structural Validation using ONNX, LibTorch, and HDF5 C++ APIs
// 2. Metadata Fingerprinting against a JSON manifest
// ------------------------------------------------------------

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

// ONNX Protobuf
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <onnx/onnx.proto3.pb.h>

// LibTorch (PyTorch C++ API)
#include <torch/script.h>

// HDF5 C++ API
#include <H5Cpp.h>

namespace fs = std::filesystem;
using json = nlohmann::json;

// ------------------------------------------------------------
// Option 1: Structural Validation
// ------------------------------------------------------------

bool validateONNX(const std::string &path) {
    // Parse ONNX model via protobuf
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    onnx::ModelProto model;
    if (!model.ParseFromIstream(&in)) return false;
    // Ensure at least one graph node exists
    return model.graph().node_size() > 0;
}

bool validatePT(const std::string &path) {
    try {
        auto module = torch::jit::load(path);
        return module != nullptr;
    } catch (...) {
        return false;
    }
}

bool validateH5(const std::string &path) {
    try {
        H5::H5File file(path, H5F_ACC_RDONLY);
        return true;
    } catch (...) {
        return false;
    }
}

bool structuralValidate(const std::string &path) {
    auto ext = fs::path(path).extension().string();
    if (ext == ".onnx")      return validateONNX(path);
    if (ext == ".pt"  || ext == ".pth")  return validatePT(path);
    if (ext == ".h5")       return validateH5(path);
    // Add more structural checks as needed...
    return false;
}

// ------------------------------------------------------------
// Option 2: Metadata Fingerprinting
// ------------------------------------------------------------

bool metadataFingerprint(const std::string &manifest_path, const std::string &artifact_path) {
    std::ifstream manifest_in(manifest_path);
    if (!manifest_in.is_open()) return false;
    json manifest; manifest_in >> manifest;

    auto ext = fs::path(artifact_path).extension().string();
    if (ext == ".onnx") {
        // Load ONNX metadata_props
        std::ifstream in(artifact_path, std::ios::binary);
        onnx::ModelProto model;
        if (!model.ParseFromIstream(&in)) return false;
        // Check each expected key
        if (manifest.contains("metadata_keys")) {
            for (const auto &key : manifest["metadata_keys"]) {
                bool found = false;
                for (const auto &prop : model.metadata_props()) {
                    if (prop.key() == key.get<std::string>()) {
                        found = true;
                        break;
                    }
                }
                if (!found) return false;
            }
        }
        return true;
    }
    // Similar fingerprinting can be added for other formats
    return false;
}

// ------------------------------------------------------------
// Example integration
// ------------------------------------------------------------

bool validateArtifact(const std::string &job_id) {
    std::string out_path = "storage/outputs/" + job_id + ".onnx"; // adjust ext
    std::string manifest = "jobs/queue/" + job_id + ".manifest.json";
    
    if (!fs::exists(manifest)) {
        // fallback to pure structural
        return structuralValidate(out_path);
    }
    // If manifest exists, enforce fingerprint then structure
    return metadataFingerprint(manifest, out_path) && structuralValidate(out_path);
}
