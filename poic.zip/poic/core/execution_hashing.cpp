#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>
#include <iomanip>         // For std::setw and std::setfill
#include <openssl/sha.h>

namespace fs = std::filesystem;

// ------------------------------------------------------------
// Function:  Reads a file in binary and returns a SHA-256 hash as a hex string
// ------------------------------------------------------------
std::string sha256File(const std::string& file_path) {
    std::ifstream file(file_path, std::ios::binary);
    if (!file.is_open()) return "";

    SHA256_CTX ctx;
    SHA256_Init(&ctx);

    char buffer[4096];
    while (file) {
        file.read(buffer, sizeof(buffer));
        std::streamsize n = file.gcount();
        if (n > 0)
            SHA256_Update(&ctx, buffer, n);
    }

    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_Final(hash, &ctx);

    std::ostringstream result;
    result << std::hex << std::setfill('0');
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i)
        result << std::setw(2) << static_cast<int>(hash[i]);
    return result.str();
}

// ------------------------------------------------------------
// Function:  Atomically write hash file (write to temp, rename)
// ------------------------------------------------------------

bool writeHashToFile(const std::string& job_id, const std::string& output_path) {
    std::string hash = sha256File(output_path);
    if (hash.empty()) {
        std::cerr << "Failed to hash output for job " << job_id << "\n";
        return false;
    }

    std::string dir = "storage/hashes/";
    fs::create_directories(dir);  // Ensure directory exists

    std::string hash_path = dir + job_id + ".hash";
    std::string temp_path = dir + job_id + ".hash.tmp";

// ------------------------------------------------------------
// Function:  Write to temp file first
// ------------------------------------------------------------
    std::ofstream out(temp_path, std::ios::trunc);
    if (!out.is_open()) {
        std::cerr << "Failed to write temp hash file for job " << job_id << "\n";
        return false;
    }
    out << hash;
    out.close();

// ------------------------------------------------------------
// Function: Atomic renam
// ------------------------------------------------------------
    try {
        fs::rename(temp_path, hash_path);
    } catch (const std::exception& e) {
        std::cerr << "Failed to move temp hash file into place: " << e.what() << "\n";
        return false;
    }

    std::cout << "✅ Wrote hash for job " << job_id << ": " << hash << "\n";
    return true;
}
