// job_scheduler.cpp
#include <iostream>
#include <filesystem>
#include <fstream>
#include <vector>
#include <map>
#include <limits>
#include <thread>
#include <chrono>
#include <nlohmann/json.hpp>
#include "node_registry.cpp"  // assumes registry is global or passed in
#include "sharding_logic.cpp" // includes shardJob(job_id)

using json = nlohmann::json;
namespace fs = std::filesystem;

// ------------------------------------------------------------
// Struct: Shard
// Purpose: Metadata of each shard
// ------------------------------------------------------------
struct Shard {
    std::string path;
    std::string job_id;
    int shard_id;
    std::string status;
    int estimated_flops;
};

// ------------------------------------------------------------
// Function: loadUnassignedShards
// Purpose: Loads all unassigned shards from disk
// ------------------------------------------------------------
std::vector<Shard> loadUnassignedShards(const std::string& dir = "jobs/shards/") {
    std::vector<Shard> shards;

    for (const auto& file : fs::directory_iterator(dir)) {
        std::ifstream in(file.path());
        json j;
        in >> j;
        if (j["status"] == "unassigned") {
            Shard s;
            s.path = file.path();
            s.job_id = j["job_id"];
            s.shard_id = j["shard_id"];
            s.status = j["status"];
            s.estimated_flops = j.value("estimated_flops", 1e9); // Default 1 GFLOP if missing
            shards.push_back(s);
        }
    }

    return shards;
}

// ------------------------------------------------------------
// Function: getAvailableNodes
// Purpose: Returns online nodes with available jobs and FLOPs
// ------------------------------------------------------------
std::vector<std::string> getAvailableNodes() {
    std::vector<std::string> available;

    for (const auto& [id, node] : registry) {
        if (node.status == "online" && node.max_jobs > 0 && node.available_flops > 0) {
            available.push_back(id);
        }
    }

    return available;
}

// ------------------------------------------------------------
// Function: assignShardsToNodes
// Purpose: Assign shards to the optimal node based on runtime estimation
// ------------------------------------------------------------
void assignShardsToNodes(const std::vector<Shard>& shards) {
    auto nodes = getAvailableNodes();
    if (nodes.empty()) {
        std::cerr << "No nodes available for scheduling.\n";
        return;
    }

    const double MAX_SHARD_RUNTIME =  1209600.0; // seconds

    for (const auto& shard : shards) {
        double best_time = std::numeric_limits<double>::max();
        std::string best_node;

        for (const auto& node_id : nodes) {
            const auto& node = registry[node_id];
            if (node.max_jobs <= 0 || node.available_flops < shard.estimated_flops) continue;

            double time_est = static_cast<double>(shard.estimated_flops) / node.flops;

            if (time_est < best_time) {
                best_time = time_est;
                best_node = node_id;
            }
        }

        if (best_node.empty()) {
            std::cerr << "❌ No suitable node for shard " << shard.shard_id << " of job " << shard.job_id << "\n";
            continue;
        }

        if (best_time > MAX_SHARD_RUNTIME) {
            std::cerr << "⚠️ Shard " << shard.shard_id << " runtime too long (" << best_time << "s), skipping assignment.\n";
            continue;
        }

        // Assign shard to best node
        std::ifstream in(shard.path);
        json j;
        in >> j;

        j["assigned_to"] = best_node;
        j["status"] = "assigned";
        j["estimated_runtime"] = best_time;

        std::ofstream out(shard.path);
        out << j.dump(4);
        out.close();

        deductFlopsFromNode(best_node, shard.estimated_flops);

        std::cout << "✅ Shard " << shard.shard_id << " of job " << shard.job_id
                  << " assigned → " << best_node
                  << " (est. runtime: " << best_time << "s)\n";
    }
}

// ------------------------------------------------------------
// Function: schedulerLoop
// Purpose: Watches for scheduled jobs and triggers sharding
// ------------------------------------------------------------
void schedulerLoop() {
    while (true) {
        for (const auto& file : fs::directory_iterator("jobs/queue/")) {
            std::ifstream in(file.path());
            json job;
            in >> job;

            if (job["status"] == "scheduled") {
                std::string job_id = job["job_id"];
                std::cout << "[Scheduler] Sharding job: " << job_id << "\n";

                shardJob(job_id);  // Trigger sharding

                job["status"] = "sharded";
                std::ofstream out(file.path());
                out << job.dump(4);
            }
        }
        std::this_thread::sleep_for(std::chrono::seconds(5));  // Polling interval
    }
}