// block_minter.cpp
#include <iostream>
#include <fstream>
#include <nlohmann/json.hpp>
#include <filesystem>
#include <ctime>
#include <random>
#include <sstream>
#include <mutex>
#include <cmath>
#include "validation.cpp"  // Pull in validateJobOutput(), hashFile

using json = nlohmann::json;
namespace fs = std::filesystem;

std::mutex block_lock;  // Thread-level lock

static const std::string DIFFICULTY_FILE = "config/difficulty.json";
static const int HALVING_INTERVAL = 210000;
static const int RETARGET_INTERVAL = 2016;
static const double BASE_REWARD = 1.0;
static const double BASELINE_FLOPS = 1e9;  // initial difficulty threshold

// ------------------------------------------------------------
// Struct: Difficulty
// Purpose: Stores current required FLOPs and last retarget height
// ------------------------------------------------------------
struct Difficulty {
    double required_flops;
    int last_retarget_height;
};

// ------------------------------------------------------------
// Function: saveDifficulty
// Purpose: Persist difficulty settings to disk
// ------------------------------------------------------------
void saveDifficulty(const Difficulty &diff) {
    json j;
    j["required_flops"] = diff.required_flops;
    j["last_retarget_height"] = diff.last_retarget_height;
    std::ofstream out(DIFFICULTY_FILE);
    if (out.is_open()) {
        out << j.dump(4);
        out.close();
    }
}

// ------------------------------------------------------------
// Function: loadDifficulty
// Purpose: Load difficulty settings from disk, or initialize
// ------------------------------------------------------------
Difficulty loadDifficulty() {
    Difficulty diff;
    if (!fs::exists(DIFFICULTY_FILE)) {
        diff.required_flops = BASELINE_FLOPS;
        diff.last_retarget_height = 0;
        saveDifficulty(diff);
    } else {
        std::ifstream in(DIFFICULTY_FILE);
        if (in.is_open()) {
            json j; in >> j;
            diff.required_flops = j.value("required_flops", BASELINE_FLOPS);
            diff.last_retarget_height = j.value("last_retarget_height", 0);
        } else {
            diff.required_flops = BASELINE_FLOPS;
            diff.last_retarget_height = 0;
        }
    }
    return diff;
}

// ------------------------------------------------------------
// Function: computeAvgFlops
// Purpose: Calculate average estimated_flops over a block range
// ------------------------------------------------------------
double computeAvgFlops(int start_height, int end_height) {
    double sum = 0.0;
    int count = 0;
    for (const auto& file : fs::directory_iterator("storage/blocks/")) {
        auto fname = file.path().filename().string();
        if (fname.rfind("block_", 0) == 0 && fname.find(".json") != std::string::npos) {
            int num = std::stoi(fname.substr(6, fname.find('.json') - 6));
            if (num >= start_height && num <= end_height) {
                std::ifstream in(file.path());
                json j; in >> j;
                sum += j.value("estimated_flops", 0.0);
                ++count;
            }
        }
    }
    return count > 0 ? (sum / count) : BASELINE_FLOPS;
}

// ------------------------------------------------------------
// Function: getReward
// Purpose: Calculate reward based on halving schedule
// ------------------------------------------------------------
double getReward(int block_num) {
    int era = block_num / HALVING_INTERVAL;
    return BASE_REWARD / std::pow(2.0, era);
}

// ------------------------------------------------------------
// Function: getRequiredFlops
// Purpose: Return current difficulty and retarget if needed
// ------------------------------------------------------------
double getRequiredFlops(int block_num) {
    Difficulty diff = loadDifficulty();
    if ((block_num - diff.last_retarget_height) >= RETARGET_INTERVAL) {
        int start = diff.last_retarget_height + 1;
        int end = block_num;
        diff.required_flops = computeAvgFlops(start, end);
        diff.last_retarget_height = block_num;
        saveDifficulty(diff);
    }
    return diff.required_flops;
}

// ------------------------------------------------------------
// Function: generateUUID
// Purpose: Generates a random UUID-like string for unique block ID
// ------------------------------------------------------------
std::string generateUUID() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(0, 15);
    static std::uniform_int_distribution<> dis2(8, 11);

    std::stringstream ss;
    ss << std::hex;
    for (int i = 0; i < 8; i++) ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 4; i++) ss << dis(gen);
    ss << "-4";
    for (int i = 0; i < 3; i++) ss << dis(gen);
    ss << "-" << dis2(gen);
    for (int i = 0; i < 3; i++) ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 12; i++) ss << dis(gen);
    return ss.str();
}

// ------------------------------------------------------------
// Function: getNextBlockNumber
// Purpose: Returns the next sequential block number
// ------------------------------------------------------------
int getNextBlockNumber() {
    int n = 0;
    for (const auto& file : fs::directory_iterator("storage/blocks/")) {
        if (file.path().filename().string().rfind("block_", 0) == 0) n++;
    }
    return n;
}

// ------------------------------------------------------------
// Function: mintBlock
// Purpose: Validates job output, enforces difficulty, then mints block and credits wallet
// Returns: true if successful, false otherwise
// ------------------------------------------------------------
bool mintBlock(const std::string& job_id, const std::string& wallet) {
    std::lock_guard<std::mutex> guard(block_lock);
    
    if (!validateJobOutput(job_id)) {
        std::cerr << "❌ Block minting aborted: Job validation failed.\n";
        return false;
    }

    // Load shard compute stats
    std::string shard_path = "jobs/shards/" + job_id + ".json";
    int estimated_flops = -1;
    if (fs::exists(shard_path)) {
        std::ifstream shard_in(shard_path);
        json shard; shard_in >> shard;
        estimated_flops = shard.value("estimated_flops", -1);
    }

    int block_num = getNextBlockNumber();
    double required = getRequiredFlops(block_num);
    if (estimated_flops < required) {
        std::cerr << "❌ Estimated FLOPs (" << estimated_flops << ") below difficulty threshold (" << required << ")\n";
        return false;
    }

    double reward = getReward(block_num);
    std::string output_file = "storage/outputs/" + job_id + ".onnx";
    std::string uuid = generateUUID();

    json block;
    block["block_id"] = block_num;
    block["uuid"] = uuid;
    block["job_id"] = job_id;
    block["wallet"] = wallet;
    block["hash"] = hashFile(output_file);
    block["timestamp"] = std::time(nullptr);
    block["reward"] = reward;
    block["estimated_flops"] = estimated_flops;
    block["difficulty"] = required;

    std::string filename = "storage/blocks/block_" + std::to_string(block_num) + ".json";
    std::ofstream out(filename);
    if (!out.is_open()) {
        std::cerr << "❌ Failed to write block file.\n";
        return false;
    }
    out << block.dump(4);
    out.close();

    std::cout << "✅ Minted PoIC block #" << block_num << " to wallet " << wallet << " (reward=" << reward << ")\n";

    // Update wallet ledger
    std::string token_file = "storage/ledger/" + wallet + ".json";
    json ledger;
    if (fs::exists(token_file)) {
        std::ifstream in(token_file); in >> ledger;
    } else {
        ledger["wallet"] = wallet;
        ledger["balance"] = 0.0;
    }
    ledger["balance"] = ledger.value("balance", 0.0) + reward;
    std::ofstream out_ledger(token_file);
    if (!out_ledger.is_open()) {
        std::cerr << "❌ Failed to update wallet ledger: " << token_file << "\n";
        return false;
    }
    out_ledger << ledger.dump(4);
    out_ledger.close();

    return true;
}
