// node_registry.cpp
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <ctime>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// ------------------------------------------------------------
// Struct: NodeInfo
// Purpose: Stores detailed node stats, including runtime compute availability
// ------------------------------------------------------------
struct NodeInfo {
    std::string id;
    std::string gpu;
    int flops;                  // FLOPs per second (performance metric)
    int session_time;           // Allowed session time (seconds)
    double total_flops;         // Total FLOPs available this session
    double available_flops;     // Remaining FLOPs for the session
    int running_jobs;           // Number of currently assigned jobs
    std::string status;         // online/offline
    std::time_t last_heartbeat; // Last online check-in
};

// Global registry map
std::unordered_map<std::string, NodeInfo> registry;

// ------------------------------------------------------------
// Function: registerNode
// Purpose: Registers a new node and initializes its resources
// ------------------------------------------------------------
void registerNode(const NodeInfo& node) {
    NodeInfo newNode = node;
    newNode.status          = "online";
    newNode.last_heartbeat  = std::time(nullptr);
    newNode.total_flops     = static_cast<double>(node.flops) * node.session_time;
    newNode.available_flops = newNode.total_flops;
    newNode.running_jobs    = 0;
    registry[node.id]       = newNode;
    std::cout << "Registered node: " << node.id << "\n";
    // Persist registry to disk
    saveRegistryToFile();
}

// ------------------------------------------------------------
// Function: heartbeat
// Purpose: Updates node online status and heartbeat timestamp
// ------------------------------------------------------------
void heartbeat(const std::string& node_id) {
    if (!registry.count(node_id)) return;
    auto& node             = registry[node_id];
    node.last_heartbeat    = std::time(nullptr);
    node.status            = "online";
    std::cout << "Node " << node_id << " heartbeat updated.\n";
    // Note: Do NOT reset available_flops here
}

// ------------------------------------------------------------
// Function: saveRegistryToFile
// Purpose: Persist registry to disk (including compute accounting)
// ------------------------------------------------------------
void saveRegistryToFile(const std::string& path = "config/nodes_registry.json") {
    json j;
    for (const auto& [id, node] : registry) {
        j[id] = {
            {"gpu", node.gpu},
            {"flops", node.flops},
            {"session_time", node.session_time},
            {"total_flops", node.total_flops},
            {"available_flops", node.available_flops},
            {"running_jobs", node.running_jobs},
            {"status", node.status},
            {"last_heartbeat", node.last_heartbeat}
        };
    }
    std::ofstream out(path);
    if (out.is_open()) {
        out << j.dump(4);
        out.close();
    }
}

// ------------------------------------------------------------
// Function: loadRegistryFromFile
// Purpose: Load registry data including compute accounting
// ------------------------------------------------------------
void loadRegistryFromFile(const std::string& path = "config/nodes_registry.json") {
    std::ifstream in(path);
    if (!in.is_open()) return;

    json j;
    in >> j;
    for (auto& [id, data] : j.items()) {
        NodeInfo n;
        n.id               = id;
        n.gpu              = data["gpu"];
        n.flops            = data["flops"];
        n.session_time     = data["session_time"];
        n.total_flops      = data.value("total_flops", n.flops * n.session_time);
        n.available_flops  = data.value("available_flops", n.total_flops);
        n.running_jobs     = data.value("running_jobs", 0);
        n.status           = data["status"];
        n.last_heartbeat   = data["last_heartbeat"];
        registry[id]       = n;
    }
}

// ------------------------------------------------------------
// Function: cleanupInactiveNodes
// Purpose: Mark nodes offline if heartbeat timeout exceeded
// ------------------------------------------------------------
void cleanupInactiveNodes(int timeout_seconds = 300) {
    std::time_t now = std::time(nullptr);
    for (auto& [id, node] : registry) {
        if ((now - node.last_heartbeat) > timeout_seconds) {
            node.status          = "offline";
            node.available_flops = 0;
            std::cout << "Node " << id << " marked offline due to inactivity.\n";
        }
    }
}

// ------------------------------------------------------------
// Function: assignShardToNode
// Purpose: Reserve FLOPs and increment job count on assignment
// ------------------------------------------------------------
bool assignShardToNode(const std::string& node_id, double flops_required) {
    if (!registry.count(node_id)) return false;
    auto& node = registry[node_id];
    if (node.available_flops >= flops_required) {
        node.available_flops -= flops_required;
        node.running_jobs += 1;
        return true;
    }
    return false;
}

// ------------------------------------------------------------
// Function: releaseShardResources
// Purpose: Reclaim FLOPs and decrement job count on completion/failure
// ------------------------------------------------------------
void releaseShardResources(const std::string& node_id, double flops_to_credit) {
    if (!registry.count(node_id)) return;
    auto& node = registry[node_id];
    if (node.status == "online") {
        node.available_flops += flops_to_credit;
        node.running_jobs -= 1;
        std::cout << "🔁 Reclaimed " << flops_to_credit << " FLOPs from node " << node_id << "\n";
    }
}
