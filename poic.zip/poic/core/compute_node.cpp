// compute_node.cpp
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <onnxruntime_cxx_api.h>
#include <nlohmann/json.hpp>
#include "execution_hashing.cpp"

using json = nlohmann::json;

// ------------------------------------------------------------
// Function: runShardJob
// Purpose:  Loads an ONNX model + input tensor, runs inference
//           via ONNX Runtime, and writes the output tensor to disk.
// ------------------------------------------------------------
bool runShardJob(const json& shard, std::string& output_path) {
    // build output filename
    std::string job_id   = shard["job_id"];
    int         shard_id = shard["shard_id"];
    std::string filename = job_id + "_shard" + std::to_string(shard_id) + ".onnx_output";
    output_path         = "storage/outputs/" + filename;

    // pull model & input paths from shard metadata
    std::string model_path = shard.value("model_path", "");
    std::string input_data = shard.value("input_data", "");
    if (model_path.empty() || input_data.empty()) {
        std::cerr << "Missing model_path or input_data in shard JSON\n";
        return false;
    }

    try {
        // 1) Create ONNX Runtime environment & session
        Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "shard_runner");
        Ort::SessionOptions opts;
        opts.SetIntraOpNumThreads(1);
        Ort::Session session(env, model_path.c_str(), opts);

        // 2) Read raw floats from input_data file
        std::ifstream inbin(input_data, std::ios::binary | std::ios::ate);
        if (!inbin.is_open()) throw std::runtime_error("Failed to open input_data");
        size_t size_bytes = inbin.tellg();
        inbin.seekg(0);
        std::vector<float> input_vals(size_bytes / sizeof(float));
        inbin.read(reinterpret_cast<char*>(input_vals.data()), size_bytes);
        inbin.close();

        // 3) Build input tensor
        Ort::AllocatorWithDefaultOptions allocator;
        auto input_shape = shard["input_shape"].get<std::vector<int64_t>>(); 
        Ort::MemoryInfo mem_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
            mem_info,
            input_vals.data(),
            input_vals.size(),
            input_shape.data(),
            input_shape.size()
        );

        // 4) Prepare I/O names
        const char* in_name  = session.GetInputName(0, allocator);
        const char* out_name = session.GetOutputName(0, allocator);

        // 5) Run inference
        auto outputs = session.Run(
            Ort::RunOptions{nullptr},
            &in_name, &input_tensor, 1,
            &out_name, 1
        );

        // 6) Extract output tensor
        float* out_data = outputs[0].GetTensorMutableData<float>();
        size_t out_count = outputs[0]
            .GetTensorTypeAndShapeInfo()
            .GetElementCount();

        // 7) Write output to disk
        std::ofstream outbin(output_path, std::ios::binary);
        if (!outbin.is_open()) throw std::runtime_error("Failed to write output file");
        outbin.write(reinterpret_cast<char*>(out_data), out_count * sizeof(float));
        outbin.close();

    } catch (const std::exception& e) {
        std::cerr << "❌ runShardJob error: " << e.what() << "\n";
        return false;
    }

    return true;
}

// ... rest of computeShard remains unchanged ...
