// sharding_logic.cpp
#include <iostream>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
namespace fs = std::filesystem;

// ------------------------------------------------------------
// Function: estimateFlopsForShard
// Purpose: Estimate how much compute this shard will use (in FLOPs)
// ------------------------------------------------------------
int estimateFlopsForShard(const std::string& input_file, const std::string& type = "inference") {
    std::ifstream in(input_file);
    int lines = 0;
    std::string line;
    while (std::getline(in, line)) lines++;
    in.close();

    // Simple heuristic:
    // Inference: 1e6 FLOPs per line
    // Training: 5e6 FLOPs per line
    int flops_per_line = (type == "training") ? 5e6 : 1e6;

    return lines * flops_per_line;
}

// ------------------------------------------------------------
// Function: createShard
// Purpose: Creates metadata for each shard and estimates required FLOPs
// ------------------------------------------------------------
void createShard(const std::string& job_id, int shard_num, const std::string& input_part, const std::string& type = "inference") {
    json shard;
    shard["job_id"] = job_id;
    shard["shard_id"] = shard_num;
    shard["input"] = input_part;
    shard["output"] = "outputs/" + job_id + "_shard" + std::to_string(shard_num) + ".out";
    shard["status"] = "unassigned";
    shard["type"] = type;
    shard["estimated_flops"] = estimateFlopsForShard(input_part, type);

    std::string shard_path = "jobs/shards/" + job_id + "_shard" + std::to_string(shard_num) + ".json";
    std::ofstream out(shard_path);
    out << shard.dump(4);
    out.close();

    std::cout << "Shard " << shard_num << " created at " << shard_path << " (est. FLOPs: " << shard["estimated_flops"] << ")\n";
}

// ------------------------------------------------------------
// Function: splitDataset
// Purpose: Splits the input dataset evenly into specified shards
// ------------------------------------------------------------
void splitDataset(const std::string& input_file, int num_shards, const std::string& prefix) {
    std::ifstream in(input_file);
    if (!in.is_open()) {
        std::cerr << "Failed to open input file.\n";
        return;
    }

    std::vector<std::ofstream> outputs(num_shards);
    for (int i = 0; i < num_shards; ++i) {
        outputs[i].open("jobs/tmp/" + prefix + "_part" + std::to_string(i) + ".csv");
    }

    std::string line;
    int i = 0;
    while (std::getline(in, line)) {
        outputs[i % num_shards] << line << "\n";
        i++;
    }

    for (auto& f : outputs) f.close();
    in.close();
}

// ------------------------------------------------------------
// Function: shardJob
// Purpose: Manages the overall sharding process for a job
// ------------------------------------------------------------
void shardJob(const std::string& job_path) {
    std::ifstream file(job_path);
    if (!file.is_open()) {
        std::cerr << "Failed to open job file.\n";
        return;
    }

    json job;
    file >> job;

    std::string job_id = job["job_id"];
    int num_shards = job["shards"];
    std::string input_file = job["input"];
    std::string type = job.value("type", "inference");

    // Step 1: split input file
    splitDataset(input_file, num_shards, job_id);

    // Step 2: create shard metadata files
    for (int i = 0; i < num_shards; ++i) {
        std::string input_part = "jobs/tmp/" + job_id + "_part" + std::to_string(i) + ".csv";
        createShard(job_id, i, input_part, type);
    }

    std::cout << "Job " << job_id << " split into " << num_shards << " shards.\n";
}
