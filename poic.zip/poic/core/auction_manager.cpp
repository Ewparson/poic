// # auction_manager.cpp

#include <iostream>
#include <fstream>
#include <nlohmann/json.hpp>
#include <vector>
#include <filesystem>
#include <algorithm>
#include <ctime>
#include "node_registry.cpp"  // Access to the node registry

// ------------------------------------------------------------
// Logger Macros
// Purpose: Simple logging for errors and warnings.
// ------------------------------------------------------------
#define LOG_ERROR(msg) std::cerr << "[ERROR] " << msg << std::endl
#define LOG_WARNING(msg) std::cerr << "[WARNING] " << msg << std::endl

using json = nlohmann::json;
namespace fs = std::filesystem;

const std::string BID_FILE     = "storage/auction_state/current_bids.json";
const std::string AUCTION_LOG  = "storage/auction_history/epoch_log.json";

struct Bid {
    std::string wallet;
    std::string job_id;
    double      amount;
    std::time_t timestamp;
};

// ------------------------------------------------------------
// Function: loadBids
// Purpose:  Read all JSON-lines from current_bids.json into a vector
// ------------------------------------------------------------
std::vector<Bid> loadBids() {
    std::vector<Bid> bids;
    std::ifstream file(BID_FILE);
    if (!file.is_open()) {
        LOG_ERROR("Failed to open bid file: " + BID_FILE);
        return bids;
    }

    std::string line;
    while (std::getline(file, line)) {
        if (line.empty()) continue;
        try {
            auto j = json::parse(line);
            bids.push_back({
                j["wallet"].get<std::string>(),
                j["job_id"].get<std::string>(),
                j["amount"].get<double>(),
                j["timestamp"].get<std::time_t>()
            });
        } catch (const json::exception& e) {
            LOG_WARNING(std::string("Skipping invalid JSON line in ") + BID_FILE + ": " + e.what());
        }
    }
    return bids;
}

// ------------------------------------------------------------
// Function: clearBidFile
// Purpose:  Truncate the bid file to prepare for the next round
// ------------------------------------------------------------
void clearBidFile() {
    std::ofstream clear(BID_FILE, std::ios::trunc);
    if (!clear.is_open()) {
        LOG_ERROR("Failed to clear bid file: " + BID_FILE);
    }
}

// ------------------------------------------------------------
// Function: processAuctionRound
// Purpose:  Load registry, compute dynamic free slots, pick top bids,
//           schedule jobs, log winners, and clear bids.
// ------------------------------------------------------------
void processAuctionRound() {
    // 1) Load registry
    NodeRegistry registry;
    if (!registry.loadFromFile("config/nodes_registry.json")) {
        LOG_ERROR("Failed to load node registry");
        return;
    }

    // 2) Compute total free slots dynamically
    int available_slots = registry.getFreeSlots();
    std::cout << "[Auction] Detected " << available_slots
              << " free slot(s) across online nodes." << std::endl;

    // 3) Load & sort bids
    auto bids = loadBids();
    if (bids.empty()) {
        std::cout << "[Auction] No bids submitted." << std::endl;
        return;
    }
    std::sort(bids.begin(), bids.end(), [](const Bid &a, const Bid &b) {
        if (a.amount != b.amount)
            return a.amount > b.amount;   // highest bid first
        return a.timestamp < b.timestamp; // earlier bid wins tie
    });

    // 4) Select winners
    int winner_count = std::min(static_cast<int>(bids.size()), available_slots);
    std::vector<Bid> winners(bids.begin(), bids.begin() + winner_count);

    // 5) Log epoch & winners
    json epoch_log;
    epoch_log["timestamp"] = std::time(nullptr);
    epoch_log["winners"]   = json::array();

    for (const auto &bid : winners) {
        std::cout << "🏆 Winner: " << bid.wallet
                  << " bid "       << bid.amount
                  << " PoIC for job " << bid.job_id << std::endl;

        epoch_log["winners"].push_back({
            {"wallet", bid.wallet},
            {"job_id", bid.job_id},
            {"amount", bid.amount}
        });

        // 6) Mark job as scheduled
        std::string job_path = "jobs/queue/" + bid.job_id + ".json";
        if (!fs::exists(job_path)) {
            LOG_WARNING("Job file not found, skipping scheduling: " + job_path);
            continue;
        }
        std::ifstream in(job_path);
        if (!in.is_open()) {
            LOG_ERROR("Failed to open job file: " + job_path);
            continue;
        }
        json job;
        try {
            in >> job;
        } catch (const json::exception& e) {
            LOG_ERROR(std::string("JSON parse error for job file ") + job_path + ": " + e.what());
            continue;
        }
        job["status"] = "scheduled";
        std::ofstream out(job_path);
        if (!out.is_open()) {
            LOG_ERROR("Failed to write job file: " + job_path);
            continue;
        }
        out << job.dump(4);
    }

    // 7) Append to auction history
    std::ofstream logOut(AUCTION_LOG, std::ios::app);
    if (!logOut.is_open()) {
        LOG_ERROR("Failed to open auction log: " + AUCTION_LOG);
    } else {
        logOut << epoch_log.dump(4) << std::endl;
    }

    // 8) Clear bid file for next epoch
    clearBidFile();
}

int main() {
    processAuctionRound();
    return 0;
}
