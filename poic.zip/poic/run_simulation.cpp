// run_simulation.cpp

#include "job.h"
#include "sharding_logic.cpp"
#include "job_scheduler.cpp"
#include "compute_node.cpp"
#include "execution_hashing.cpp"
#include "validation.cpp"
#include "block_minter.cpp"

int main() {
    std::string job_id = "job_sim001";

    // 1. Generate a mock job
    Job job = {
        job_id,
        "0xtestwallet",
        "model_fake_v1.pth",
        "data/fake_input.csv",
        "inference",
        1,
        0.0,
        "unassigned",
        std::time(nullptr)
    };

    std::ofstream out("jobs/queue/" + job_id + ".json");
    out << job.to_json().dump(4);
    out.close();

    // 2. Shard the job
    shardJob("jobs/queue/" + job_id + ".json");

    // 3. Assign shard manually to fake node
    auto shards = loadUnassignedShards();
    for (auto& s : shards) {
        std::ifstream in(s.path);
        json j;
        in >> j;
        j["status"] = "assigned";
        j["assigned_to"] = "node_sim";
        std::ofstream out(s.path);
        out << j.dump(4);
    }

    // 4. Run compute (fake AI output)
    computeShard("jobs/shards/" + job_id + "_shard0.json");

    // 5. Validate it
    if (validateJobOutput(job_id + "_shard0")) {
        std::string hash = hashFile("storage/outputs/" + job_id + "_shard0.out");
        mintBlock(job_id + "_shard0", "0xtestwallet", hash);
    } else {
        std::cout << "❌ Simulation failed validation.\n";
    }

    return 0;
}
